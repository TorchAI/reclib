# reclib
---

A python package that provides many recommendation algorithms and let users train and test on their own datasets.

## Setup

`pip install reclib`

## Features

- Pythonic
- Easy to use
- State-of-the-art


## Models

Please refer to the documents

|       |       |       |       |       |
|---    |---    |---    |---    |---    |
|       |       |       |       |       |
|       |       |       |       |       |
|       |       |       |       |       |


## Contributions
Contributions are welcome


## Licence

 
